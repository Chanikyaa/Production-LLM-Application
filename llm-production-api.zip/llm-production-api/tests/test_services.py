from llm_api.services import InMemoryRateLimiter, TTLCache, UsageLedger


def test_rate_limiter_blocks_after_limit() -> None:
    limiter = InMemoryRateLimiter(requests=2, window_seconds=60)
    assert limiter.allow("client")
    assert limiter.allow("client")
    assert not limiter.allow("client")


def test_cache_returns_copy_and_evicts_to_bound() -> None:
    cache = TTLCache(ttl_seconds=60, max_entries=1)
    cache.set("a", {"value": 1})
    value = cache.get("a")
    assert value == {"value": 1}
    value["value"] = 9
    assert cache.get("a") == {"value": 1}
    cache.set("b", {"value": 2})
    assert cache.get("a") is None
    assert cache.get("b") == {"value": 2}


def test_cost_is_only_reported_when_usage_is_known() -> None:
    ledger = UsageLedger(input_cost_per_1k_usd=1.0, output_cost_per_1k_usd=2.0)
    assert ledger.record(None, 10) is None
    assert ledger.record(1000, 500) == 2.0
