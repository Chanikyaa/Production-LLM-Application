from fastapi.testclient import TestClient

from llm_api.main import app

client = TestClient(app)
AUTH = {"Authorization": "Bearer test-secret"}


def test_health_endpoints_are_available_without_auth() -> None:
    assert client.get("/health/live").json() == {"status": "ok"}
    assert client.get("/health/ready").status_code == 200


def test_chat_requires_authentication() -> None:
    response = client.post("/v1/chat", json={"prompt": "hello"})
    assert response.status_code == 401


def test_chat_mock_mode_returns_valid_response_and_request_id() -> None:
    response = client.post("/v1/chat", headers=AUTH, json={"prompt": "Explain RAG"})
    assert response.status_code == 200
    data = response.json()
    assert data["provider"] == "mock"
    assert "Explain RAG" in data["output"]
    assert data["request_id"]
    assert response.headers["x-request-id"] == data["request_id"]


def test_cache_marks_second_response_as_cached() -> None:
    payload = {"prompt": "cache test unique"}
    first = client.post("/v1/chat", headers=AUTH, json=payload).json()
    second = client.post("/v1/chat", headers=AUTH, json=payload).json()
    assert first["cached"] is False
    assert second["cached"] is True
    assert first["output"] == second["output"]


def test_invalid_request_fields_are_rejected() -> None:
    response = client.post("/v1/chat", headers=AUTH, json={"prompt": " ", "unexpected": True})
    assert response.status_code == 422


def test_stream_endpoint_returns_server_sent_events() -> None:
    response = client.post("/v1/chat/stream", headers=AUTH, json={"prompt": "stream me"})
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    assert "[DONE]" in response.text


def test_openapi_documentation_is_available() -> None:
    response = client.get("/openapi.json")
    assert response.status_code == 200
    assert "/v1/chat" in response.json()["paths"]


def test_browser_demo_is_served() -> None:
    response = client.get("/")
    assert response.status_code == 200
    assert "LLM API Demo" in response.text
