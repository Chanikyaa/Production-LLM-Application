import os

os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("API_BEARER_TOKEN", "test-secret")
os.environ.setdefault("LLM_PROVIDER", "mock")
