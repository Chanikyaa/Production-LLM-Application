#!/usr/bin/env bash
set -euo pipefail
export APP_ENV=local
export API_BEARER_TOKEN="${API_BEARER_TOKEN:-change-me-for-non-local-use}"
export LLM_PROVIDER=mock
python -m uvicorn llm_api.main:app --host 127.0.0.1 --port 8000
