"""Tiny standard-library load smoke test; start the API before running this script."""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import time
import urllib.error
import urllib.request


def request_once(url: str, token: str) -> tuple[int, float]:
    body = json.dumps({"prompt": "Return a short greeting", "use_cache": False}).encode()
    request = urllib.request.Request(
        url, data=body, method="POST",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
    )
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            response.read()
            return response.status, (time.perf_counter() - started) * 1000
    except urllib.error.HTTPError as exc:
        return exc.code, (time.perf_counter() - started) * 1000


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default="http://127.0.0.1:8000/v1/chat")
    parser.add_argument("--token", default="change-me-for-non-local-use")
    parser.add_argument("--requests", type=int, default=20)
    parser.add_argument("--concurrency", type=int, default=4)
    args = parser.parse_args()
    if args.requests < 1 or args.concurrency < 1:
        parser.error("requests and concurrency must be positive")
    started = time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        results = list(pool.map(lambda _: request_once(args.url, args.token), range(args.requests)))
    latencies = sorted(latency for _, latency in results)
    successes = sum(status == 200 for status, _ in results)
    p95 = latencies[min(len(latencies) - 1, int(0.95 * len(latencies)))]
    print(json.dumps({
        "requests": len(results), "successes": successes,
        "errors": len(results) - successes,
        "wall_time_seconds": round(time.perf_counter() - started, 3),
        "latency_p50_ms": round(latencies[len(latencies) // 2], 2),
        "latency_p95_ms": round(p95, 2),
    }, indent=2))


if __name__ == "__main__":
    main()
