# Production-Oriented LLM API

A compact FastAPI service demonstrating provider abstraction, validated request contracts, optional SSE responses, authentication, rate limiting, caching, usage accounting, request IDs, health checks, Docker, and CI. It runs in deterministic mock mode without a paid API key.

> **Status:** MVP. Local tests are intended to run without network calls to an LLM provider. Public deployment is not recommended until the security gaps in `docs/threat-model.md` are addressed.

## Problem and intended users

AI features often start as scripts. This repository shows how to wrap model generation in a service with explicit contracts, operational limits, observability, and testability. It is intended for AI Engineer, Applied AI, Generative AI, and backend-oriented ML roles.

## Features
- FastAPI routes with Pydantic validation and OpenAPI docs.
- Provider interface: deterministic `mock` mode and optional OpenAI-compatible Chat Completions endpoint.
- `/v1/chat` response API and `/v1/chat/stream` SSE endpoint.
- Bearer-token authentication, request-size guard, per-process rate limit, and bounded TTL cache.
- Request IDs, response latency headers, structured logs, health endpoints, and usage/cost estimates where usage is available.
- Docker, Compose, CI, unit/API tests, and a standard-library load smoke test.

## Non-goals
No claim of multi-tenant production readiness, distributed rate limiting, persistent analytics, prompt-injection immunity, or provider-agnostic compatibility with every vendor. SSE currently chunks the completed response after generation; upstream token streaming is a future enhancement.

## Architecture
See [`docs/architecture.md`](docs/architecture.md) and [`docs/threat-model.md`](docs/threat-model.md).

## Prerequisites
Python 3.11+ and pip. Docker is optional. A real provider requires an API key and may incur charges.

## Install

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\Activate.ps1
python -m pip install -e ".[dev]"
cp .env.example .env  # reference only; export variables in your shell or configure your runner
```

The app reads environment variables directly and does not automatically load `.env`.

## Run in free mock mode

```bash
export APP_ENV=local
export API_BEARER_TOKEN=change-me-for-non-local-use
export LLM_PROVIDER=mock
uvicorn llm_api.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/docs`. Example request:

```bash
curl -s http://127.0.0.1:8000/v1/chat \\
  -H 'Authorization: Bearer change-me-for-non-local-use' \\
  -H 'Content-Type: application/json' \\
  -d '{"prompt":"Explain retrieval-augmented generation in one sentence."}'
```

Example response shape (request ID and usage values vary):

```json
{
  "request_id": "generated-request-id",
  "model": "mock-v1",
  "provider": "mock",
  "output": "Mock response: Explain retrieval-augmented generation in one sentence.",
  "usage": {"input_tokens": 18, "output_tokens": 19, "estimated_cost_usd": 0.0},
  "cached": false
}
```

## Optional real provider
Set `LLM_PROVIDER=openai-compatible`, `LLM_API_KEY`, `LLM_BASE_URL`, and `LLM_MODEL`. The adapter sends a Chat Completions-style request and uses configured timeouts. Verify your chosen provider supports this API shape before use. Costs are provider-specific; set `INPUT_COST_PER_1K_USD` and `OUTPUT_COST_PER_1K_USD` only to current known rates. Never commit keys.

## Streaming demo

```bash
curl -N http://127.0.0.1:8000/v1/chat/stream \\
  -H 'Authorization: Bearer change-me-for-non-local-use' \\
  -H 'Content-Type: application/json' \\
  -d '{"prompt":"Give three API reliability tips."}'
```

This MVP streams response text in SSE chunks after the provider returns; it does not yet relay provider tokens as they arrive.

## Tests and quality

```bash
pytest -q
ruff check .
python scripts/load_test.py --token change-me-for-non-local-use
```

Only report checks that you actually ran. Hosted GitHub Actions runs only after repository publication or push.

## Docker

```bash
docker compose up --build
```
Compose binds to `127.0.0.1:8000` and defaults to mock mode. Set a strong token for shared environments. The container runs as non-root and uses a read-only root filesystem with a temporary directory.

## Security, privacy, limitations
See [`docs/threat-model.md`](docs/threat-model.md). Do not log prompts by default. Avoid sending sensitive information to third-party providers without authorization. Shared-token auth and in-memory controls are learning-grade and not suitable as the only controls on a public service.

## Personal contribution
Before using this repository in a resume, review and understand the provider abstraction, request validation, authentication, rate limiting, caching, cost estimation, and tests. Document your own changes and measured results; do not claim results you have not verified.

## License
MIT.
