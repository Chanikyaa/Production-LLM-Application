# Portfolio tracker

| Project | Target roles | Technologies | Implementation | Tests | Evaluation | Deployment | GitHub |
|---|---|---|---|---|---|---|---|
| Project 4: Production-Oriented LLM API | AI Engineer, Applied AI, GenAI Engineer | FastAPI, Pydantic, httpx, Docker | MVP implemented | Local tests pending first run | Load script included; no benchmark claimed | Docker config included; image not yet built | Not published |

## Engineering log
- Added deterministic mock provider so tests and demos do not require paid API access.
- Added optional OpenAI-compatible provider adapter, request validation, bearer auth, bounded cache, per-process rate limiter, structured logs, health endpoints, usage accounting, SSE response endpoint, Docker, CI, and docs.
- Known limitation: SSE is chunked after complete generation; not upstream token streaming.
- Known limitation: auth, limiter, cache, and metrics are process-local MVP implementations.
