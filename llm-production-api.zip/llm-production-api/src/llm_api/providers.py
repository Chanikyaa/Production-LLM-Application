"""Provider adapters. Mock mode is deterministic and requires no network or API key."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Protocol

import httpx


@dataclass(frozen=True, slots=True)
class ProviderResult:
    output: str
    model: str
    input_tokens: int | None = None
    output_tokens: int | None = None


class LLMProvider(Protocol):
    name: str

    async def generate(
        self, *, system_prompt: str, prompt: str, temperature: float, max_output_tokens: int
    ) -> ProviderResult: ...


def estimate_tokens(text: str) -> int:
    """Cheap approximate token count; never present this as provider-reported usage."""
    return max(1, (len(text) + 3) // 4)


class MockProvider:
    name = "mock"

    async def generate(
        self, *, system_prompt: str, prompt: str, temperature: float, max_output_tokens: int
    ) -> ProviderResult:
        del temperature
        clean = re.sub(r"\s+", " ", prompt).strip()
        output = f"Mock response: {clean[: max_output_tokens * 4]}"
        return ProviderResult(
            output=output,
            model="mock-v1",
            input_tokens=estimate_tokens(system_prompt + prompt),
            output_tokens=estimate_tokens(output),
        )


class OpenAICompatibleProvider:
    """Adapter for providers implementing the OpenAI chat-completions HTTP shape."""

    name = "openai-compatible"

    def __init__(self, *, api_key: str, base_url: str, model: str, timeout_seconds: float) -> None:
        if not api_key:
            raise ValueError("LLM_API_KEY is required for openai-compatible provider")
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        self.timeout_seconds = timeout_seconds

    async def generate(
        self, *, system_prompt: str, prompt: str, temperature: float, max_output_tokens: int
    ) -> ProviderResult:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            "temperature": temperature,
            "max_tokens": max_output_tokens,
        }
        timeout = httpx.Timeout(self.timeout_seconds, connect=min(5.0, self.timeout_seconds))
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"{self.base_url}/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json=payload,
            )
            response.raise_for_status()
        data = response.json()
        try:
            output = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError("Provider returned an unexpected response shape") from exc
        if not isinstance(output, str):
            raise RuntimeError("Provider returned non-text message content")
        usage = data.get("usage") or {}
        input_tokens = usage.get("prompt_tokens")
        output_tokens = usage.get("completion_tokens")
        return ProviderResult(
            output=output,
            model=str(data.get("model", self.model)),
            input_tokens=input_tokens if isinstance(input_tokens, int) else None,
            output_tokens=output_tokens if isinstance(output_tokens, int) else None,
        )
