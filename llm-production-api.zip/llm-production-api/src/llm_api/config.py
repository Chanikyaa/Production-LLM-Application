"""Environment-based configuration with conservative defaults."""

from __future__ import annotations

import os
from dataclasses import dataclass


def _positive_int(name: str, default: int) -> int:
    raw = os.getenv(name, str(default))
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc
    if value <= 0:
        raise ValueError(f"{name} must be positive")
    return value


def _nonnegative_float(name: str, default: float = 0.0) -> float:
    raw = os.getenv(name, str(default))
    try:
        value = float(raw)
    except ValueError as exc:
        raise ValueError(f"{name} must be numeric") from exc
    if value < 0:
        raise ValueError(f"{name} must be non-negative")
    return value


@dataclass(frozen=True, slots=True)
class Settings:
    app_env: str
    bearer_token: str
    provider: str
    api_key: str
    base_url: str
    model: str
    timeout_seconds: float
    max_request_chars: int
    rate_limit_requests: int
    rate_limit_window_seconds: int
    cache_ttl_seconds: int
    cache_max_entries: int
    input_cost_per_1k_usd: float
    output_cost_per_1k_usd: float
    log_level: str

    @classmethod
    def from_env(cls) -> "Settings":
        provider = os.getenv("LLM_PROVIDER", "mock").strip().lower()
        if provider not in {"mock", "openai-compatible"}:
            raise ValueError("LLM_PROVIDER must be 'mock' or 'openai-compatible'")
        timeout = float(os.getenv("LLM_TIMEOUT_SECONDS", "20"))
        if timeout <= 0:
            raise ValueError("LLM_TIMEOUT_SECONDS must be positive")
        return cls(
            app_env=os.getenv("APP_ENV", "local"),
            bearer_token=os.getenv("API_BEARER_TOKEN", "change-me-for-non-local-use"),
            provider=provider,
            api_key=os.getenv("LLM_API_KEY", ""),
            base_url=os.getenv("LLM_BASE_URL", "https://api.openai.com/v1").rstrip("/"),
            model=os.getenv("LLM_MODEL", "gpt-4o-mini"),
            timeout_seconds=timeout,
            max_request_chars=_positive_int("MAX_REQUEST_CHARS", 12000),
            rate_limit_requests=_positive_int("RATE_LIMIT_REQUESTS", 30),
            rate_limit_window_seconds=_positive_int("RATE_LIMIT_WINDOW_SECONDS", 60),
            cache_ttl_seconds=_positive_int("CACHE_TTL_SECONDS", 30),
            cache_max_entries=_positive_int("CACHE_MAX_ENTRIES", 256),
            input_cost_per_1k_usd=_nonnegative_float("INPUT_COST_PER_1K_USD"),
            output_cost_per_1k_usd=_nonnegative_float("OUTPUT_COST_PER_1K_USD"),
            log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
        )
