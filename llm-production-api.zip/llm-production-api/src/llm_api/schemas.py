"""Validated API request and response models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    prompt: str = Field(min_length=1, max_length=12000)
    system_prompt: str = Field(default="You are a helpful assistant.", max_length=2000)
    temperature: float = Field(default=0.2, ge=0, le=2)
    max_output_tokens: int = Field(default=512, ge=1, le=4096)
    use_cache: bool = True

    @field_validator("prompt", "system_prompt")
    @classmethod
    def reject_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("must not be blank")
        return value


class Usage(BaseModel):
    input_tokens: int | None = None
    output_tokens: int | None = None
    estimated_cost_usd: float | None = None


class ChatResponse(BaseModel):
    request_id: str
    model: str
    provider: str
    output: str
    usage: Usage
    cached: bool = False
