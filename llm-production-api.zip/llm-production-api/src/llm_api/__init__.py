"""Production-oriented LLM API portfolio project."""

__version__ = "0.1.0"
