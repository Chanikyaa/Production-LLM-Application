"""Bounded in-memory cache, rate limiter, and usage/cost accounting helpers."""

from __future__ import annotations

import hashlib
import json
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from threading import Lock
from typing import Any


class TTLCache:
    def __init__(self, ttl_seconds: int, max_entries: int) -> None:
        self.ttl_seconds = ttl_seconds
        self.max_entries = max_entries
        self._data: dict[str, tuple[float, dict[str, Any]]] = {}
        self._lock = Lock()

    @staticmethod
    def key(payload: dict[str, Any]) -> str:
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode()).hexdigest()

    def get(self, key: str) -> dict[str, Any] | None:
        now = time.monotonic()
        with self._lock:
            item = self._data.get(key)
            if item is None:
                return None
            expires, value = item
            if expires <= now:
                self._data.pop(key, None)
                return None
            return value.copy()

    def set(self, key: str, value: dict[str, Any]) -> None:
        now = time.monotonic()
        with self._lock:
            expired = [k for k, (expiry, _) in self._data.items() if expiry <= now]
            for k in expired:
                self._data.pop(k, None)
            if key not in self._data and len(self._data) >= self.max_entries:
                oldest = min(self._data, key=lambda k: self._data[k][0])
                self._data.pop(oldest, None)
            self._data[key] = (now + self.ttl_seconds, value.copy())


class InMemoryRateLimiter:
    """Single-process fixed-window limiter. Use a shared store for multi-worker deployments."""

    def __init__(self, requests: int, window_seconds: int) -> None:
        self.requests = requests
        self.window_seconds = window_seconds
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        cutoff = now - self.window_seconds
        with self._lock:
            hits = self._hits[key]
            while hits and hits[0] <= cutoff:
                hits.popleft()
            if len(hits) >= self.requests:
                return False
            hits.append(now)
            return True


@dataclass(slots=True)
class UsageLedger:
    input_cost_per_1k_usd: float
    output_cost_per_1k_usd: float
    input_tokens_total: int = 0
    output_tokens_total: int = 0
    requests_total: int = 0

    def record(self, input_tokens: int | None, output_tokens: int | None) -> float | None:
        self.requests_total += 1
        if input_tokens is None or output_tokens is None:
            return None
        self.input_tokens_total += input_tokens
        self.output_tokens_total += output_tokens
        return round(
            input_tokens * self.input_cost_per_1k_usd / 1000
            + output_tokens * self.output_cost_per_1k_usd / 1000,
            8,
        )
