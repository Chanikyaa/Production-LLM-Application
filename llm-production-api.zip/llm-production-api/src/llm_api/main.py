"""FastAPI application with authentication, bounded resources, and observability."""

from __future__ import annotations

import json
import logging
import os
import time
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import ValidationError

from llm_api.config import Settings
from llm_api.providers import MockProvider, OpenAICompatibleProvider, ProviderResult
from llm_api.schemas import ChatRequest, ChatResponse, Usage
from llm_api.services import InMemoryRateLimiter, TTLCache, UsageLedger

settings = Settings.from_env()
logging.basicConfig(level=settings.log_level, format="%(message)s")
logger = logging.getLogger("llm_api")


def build_provider(config: Settings) -> Any:
    if config.provider == "mock":
        return MockProvider()
    return OpenAICompatibleProvider(
        api_key=config.api_key,
        base_url=config.base_url,
        model=config.model,
        timeout_seconds=config.timeout_seconds,
    )


provider = build_provider(settings)
cache = TTLCache(settings.cache_ttl_seconds, settings.cache_max_entries)
limiter = InMemoryRateLimiter(settings.rate_limit_requests, settings.rate_limit_window_seconds)
ledger = UsageLedger(settings.input_cost_per_1k_usd, settings.output_cost_per_1k_usd)


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    logger.info(json.dumps({"event": "app_start", "provider": settings.provider, "env": settings.app_env}))
    yield
    logger.info(json.dumps({"event": "app_shutdown"}))


app = FastAPI(
    title="Production-Oriented LLM API",
    version="0.1.0",
    description="LLM API with mock mode, provider abstraction, streaming, and operational controls.",
    lifespan=lifespan,
)


async def authenticate(authorization: str | None = Header(default=None)) -> str:
    """Bearer-token auth. For production, replace shared token auth with an identity provider."""
    expected = settings.bearer_token
    if not expected or expected == "change-me-for-non-local-use" and settings.app_env != "local":
        raise HTTPException(status_code=503, detail="Authentication is not securely configured")
    if authorization is None or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token", headers={"WWW-Authenticate": "Bearer"})
    supplied = authorization.removeprefix("Bearer ").strip()
    import secrets

    if not secrets.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail="Invalid bearer token", headers={"WWW-Authenticate": "Bearer"})
    return "authenticated-client"


@app.middleware("http")
async def request_context(request: Request, call_next: Any) -> Response:
    request_id = request.headers.get("x-request-id", "")[:100] or str(uuid.uuid4())
    request.state.request_id = request_id
    started = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception:
        logger.exception(json.dumps({"event": "request_unhandled_error", "request_id": request_id}))
        raise
    elapsed_ms = round((time.perf_counter() - started) * 1000, 2)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Response-Time-Ms"] = str(elapsed_ms)
    logger.info(json.dumps({
        "event": "http_request", "request_id": request_id,
        "method": request.method, "path": request.url.path,
        "status_code": response.status_code, "latency_ms": elapsed_ms,
    }))
    return response


def _usage(result: ProviderResult) -> Usage:
    cost = ledger.record(result.input_tokens, result.output_tokens)
    return Usage(
        input_tokens=result.input_tokens,
        output_tokens=result.output_tokens,
        estimated_cost_usd=cost,
    )


def _cache_payload(body: ChatRequest) -> dict[str, Any]:
    return {
        "provider": settings.provider, "model": settings.model,
        "prompt": body.prompt, "system_prompt": body.system_prompt,
        "temperature": body.temperature, "max_output_tokens": body.max_output_tokens,
    }


async def _generate(body: ChatRequest, request_id: str) -> ChatResponse:
    key = cache.key(_cache_payload(body))
    if body.use_cache:
        cached = cache.get(key)
        if cached is not None:
            cached["request_id"] = request_id
            cached["cached"] = True
            return ChatResponse.model_validate(cached)
    try:
        result = await provider.generate(
            system_prompt=body.system_prompt,
            prompt=body.prompt,
            temperature=body.temperature,
            max_output_tokens=body.max_output_tokens,
        )
    except Exception as exc:
        # Provider details and credentials must never leak through public errors.
        logger.warning(json.dumps({"event": "provider_error", "request_id": request_id, "kind": type(exc).__name__}))
        raise HTTPException(status_code=502, detail="LLM provider request failed") from exc
    response = ChatResponse(
        request_id=request_id, model=result.model, provider=settings.provider,
        output=result.output, usage=_usage(result), cached=False,
    )
    if body.use_cache:
        cache.set(key, response.model_dump())
    logger.info(json.dumps({
        "event": "llm_completion", "request_id": request_id, "provider": settings.provider,
        "model": result.model, "input_tokens": result.input_tokens,
        "output_tokens": result.output_tokens,
    }))
    return response


@app.get("/", include_in_schema=False)
async def demo_ui() -> FileResponse:
    """Serve a minimal same-origin browser demo; credentials are held only in page memory."""
    return FileResponse(os.path.join(os.path.dirname(__file__), "static", "index.html"))


@app.get("/health/live", tags=["health"])
async def liveness() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/health/ready", tags=["health"])
async def readiness() -> dict[str, str]:
    if settings.provider == "openai-compatible" and not settings.api_key:
        raise HTTPException(status_code=503, detail="Provider credentials are not configured")
    return {"status": "ready", "provider": settings.provider}


@app.get("/metrics", tags=["operations"], dependencies=[Depends(authenticate)])
async def metrics() -> dict[str, int | str]:
    """Minimal process-local metrics; protect this endpoint like other operational data."""
    return {
        "provider": settings.provider,
        "requests_with_usage": ledger.requests_total,
        "input_tokens_total": ledger.input_tokens_total,
        "output_tokens_total": ledger.output_tokens_total,
    }


@app.post("/v1/chat", response_model=ChatResponse, tags=["chat"])
async def chat(
    body: ChatRequest,
    request: Request,
    _: str = Depends(authenticate),
) -> ChatResponse:
    if len(body.prompt) + len(body.system_prompt) > settings.max_request_chars:
        raise HTTPException(status_code=413, detail="Prompt exceeds configured character limit")
    client_host = request.client.host if request.client else "unknown"
    if not limiter.allow(client_host):
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    return await _generate(body, request.state.request_id)


@app.post("/v1/chat/stream", tags=["chat"])
async def chat_stream(
    body: ChatRequest,
    request: Request,
    _: str = Depends(authenticate),
) -> StreamingResponse:
    """SSE stream. Current provider adapter completes first, then streams text in chunks."""
    if len(body.prompt) + len(body.system_prompt) > settings.max_request_chars:
        raise HTTPException(status_code=413, detail="Prompt exceeds configured character limit")
    client_host = request.client.host if request.client else "unknown"
    if not limiter.allow(client_host):
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    result = await _generate(body.model_copy(update={"use_cache": False}), request.state.request_id)

    async def events() -> AsyncIterator[str]:
        for start in range(0, len(result.output), 32):
            chunk = {"request_id": result.request_id, "delta": result.output[start : start + 32]}
            yield f"data: {json.dumps(chunk)}\n\n"
        yield f"data: {json.dumps({'request_id': result.request_id, 'usage': result.usage.model_dump()})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(events(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})


def run() -> None:
    import uvicorn

    uvicorn.run("llm_api.main:app", host="0.0.0.0", port=int(os.getenv("PORT", "8000")), log_level="info")


if __name__ == "__main__":
    run()
