# Operations and evaluation

## Health
- `GET /health/live`: process liveness.
- `GET /health/ready`: verifies the configured provider has minimum configuration; it does not make a live provider network call.
- `GET /metrics`: authenticated process-local usage counters.

## Cost accounting
The API reports provider-reported token counts when present. Estimated cost is only computed when both token counts are available and operator-configured per-1K prices are nonzero. Prices can change; estimates are not invoices. Mock token counts are approximate character-based estimates.

## Load smoke test
Start the API and run:

```bash
python scripts/load_test.py --token change-me-for-non-local-use --requests 20 --concurrency 4
```

The script reports observed results from that run. Do not copy results into the README as general performance claims without preserving the environment, date, command, and run output.

## CI
CI installs the project, runs Ruff, and executes tests. Hosted CI status remains unknown until pushed to GitHub.
