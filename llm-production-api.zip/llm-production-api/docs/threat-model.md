# Threat model and privacy notes

## Assets
- Provider API credentials.
- Prompts and model responses, which may contain confidential user content.
- Availability and provider spend.

## Trust boundaries
- Incoming HTTP requests are untrusted.
- Provider responses are untrusted external data.
- Environment configuration is trusted only when controlled by the operator.

## Controls implemented
- Pydantic validation and rejection of unexpected request fields.
- Request size cap, bearer authentication, per-process rate limit, provider timeout.
- Bounded TTL cache; cache keys are SHA-256 digests of canonical request configuration.
- Generic provider errors returned to callers; exception details and prompts are not logged.
- Request IDs, response latency, status code, provider/model labels, and token usage logs.
- Mock mode needs no credentials; Docker binds to loopback in Compose and runs as a non-root user.

## Known gaps
- Shared static bearer token; no user/tenant identity or rotation workflow.
- Rate limiter and metrics are process-local and reset on restart.
- No distributed quota, persistent usage ledger, TLS termination, WAF, or secrets manager.
- Provider request/response payloads exist in process memory during generation.
- The SSE endpoint buffers the provider response before chunking; do not describe it as live token streaming.
- Prompt injection and unsafe model content cannot be solved by a generic prompt; downstream actions require explicit validation and authorization.

## Deployment requirements before public exposure
Use HTTPS, managed secrets, an identity provider, shared rate limiting, resource quotas, monitoring/alerts, log retention policy, dependency scanning, and a documented data retention policy. Do not send regulated or confidential data to an external provider without appropriate approval and contractual controls.
