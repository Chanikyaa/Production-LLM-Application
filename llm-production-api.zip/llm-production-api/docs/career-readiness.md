# Career readiness: Production-Oriented LLM API

## Target roles and skills
AI Engineer, Applied AI Engineer, Generative AI Engineer, Backend/ML Platform Engineer. Demonstrates API design, Pydantic validation, provider abstraction, failure handling, auth, caching, rate limiting, logging, token/cost accounting, Docker, and tests.

## Requirement-to-feature mapping
- API contracts: `schemas.py` and FastAPI OpenAPI.
- Provider abstraction: `providers.py` with mock and OpenAI-compatible adapters.
- Auth/resource limits: `authenticate`, request size guard, `InMemoryRateLimiter`.
- Observability: request ID and latency middleware, structured logs, health and metrics endpoints.
- Reliability: bounded cache, provider timeout, generic public errors.
- CI/deployment: `.github/workflows/ci.yml`, Dockerfile, Compose.

## Resume bullet templates
1. Built a FastAPI LLM service with **[verified test count]** automated tests, Pydantic contracts, and mock/provider adapters for **[verified use case]**.
2. Implemented request authentication, per-process rate limiting, bounded response caching, and request-ID/latency observability; measured **[actual load-test result and environment]**.
3. Added token usage and configurable cost estimates for providers returning usage metadata, reducing manual tracking by **[measured result, if measured]**.

Do not fill placeholders with invented values.

## Five-minute demo
1. (0:00–0:45) Explain problem and architecture.
2. (0:45–1:30) Show `/docs`, health endpoints, and mock response.
3. (1:30–2:15) Demonstrate missing/invalid bearer token and validation failure.
4. (2:15–3:00) Show cache hit and request-ID/latency headers.
5. (3:00–3:45) Show SSE response and explain the buffering limitation honestly.
6. (3:45–5:00) Explain provider adapter, tests, Docker, and threat model.

## Two-minute architecture explanation
The FastAPI layer owns validation, auth, request IDs, and HTTP contracts. A provider interface isolates the model API from business logic. A deterministic mock makes tests and local demos repeatable without network calls or spend. A bounded TTL cache and per-process rate limiter limit repeated work. Usage is recorded only when token metadata is available, and cost is an estimate based on operator-provided prices. Docker and CI provide a repeatable packaging and quality-check path. The service is an MVP because shared-state controls, robust identity, true upstream streaming, and deployment hardening are not implemented.

## Interview questions with answers
1. **Why a provider abstraction?** It isolates vendor-specific payloads and response parsing, allowing the API layer to stay stable.
2. **Why mock mode?** It enables deterministic tests without credentials, network dependencies, or spend.
3. **Why Pydantic?** It validates request shapes and produces API schemas, rejecting unexpected fields.
4. **Why authenticate health separately?** Liveness checks should be easy for orchestration; operational metrics are protected.
5. **Why compare_digest?** It avoids ordinary early-exit string comparison for bearer tokens.
6. **Why not return provider errors?** Raw errors can reveal internal URLs, request details, or sensitive provider information.
7. **What is the rate-limiter limitation?** It is per process; each worker has independent counters and restarts reset them.
8. **Why bound the cache?** Unbounded prompt caches can exhaust memory; TTL and capacity limit retention.
9. **Why hash cache keys?** It avoids using raw prompt text as the dictionary key, though the digest is not encryption.
10. **When is cost unknown?** If provider usage metadata is absent, token counts and cost are not reliably known.
11. **Are mock token counts exact?** No. They are rough character-based estimates for demonstration only.
12. **Is SSE token streaming?** Not yet. This implementation chunks the final text after generation; true streaming needs provider stream parsing and disconnect handling.
13. **Why request IDs?** They correlate HTTP latency logs and provider completion events without logging prompts.
14. **What is the timeout protecting?** It bounds time spent waiting for the external provider, subject to client behavior.
15. **What should happen on provider failure?** Return a generic 502 and log a sanitized failure category tied to request ID.
16. **Why Docker non-root?** It reduces privilege if the process or dependency is compromised.
17. **Why keep secrets in environment configuration?** It separates secrets from source control; production should use a secret manager.
18. **How would you scale rate limits?** Move counters to a shared store such as Redis or an API gateway and define identity-aware quotas.
19. **How would you improve cost controls?** Add per-user budgets, model allowlists, token caps, provider price updates, and alert thresholds.
20. **What makes it production-ready?** Security review, distributed controls, real provider streaming, load tests, monitoring, deployment rollback, and privacy/legal review—not just Docker.

## Five debugging/system-design scenarios
1. **Many 429s in a multi-worker deployment:** identify per-worker counters; move to shared rate limiting and observe client identity.
2. **Cost fields show null:** inspect provider response usage; avoid guessing if the provider does not return usage.
3. **Cache serves stale answers:** tune TTL or disable cache for volatile requests; include all generation parameters in key.
4. **SSE feels delayed:** current endpoint waits for full completion; implement upstream streaming and cancellation.
5. **API latency rises:** separate provider latency from application latency; inspect request IDs, p95, timeouts, cache hit rate, and rate-limit behavior.

## Likely interviewer objections
- **“This isn't truly production grade.”** Agree: it is a production-oriented learning MVP; shared auth/rate limiting, robust telemetry, true token streaming, and operational hardening remain.
- **“Mock responses aren't AI quality.”** Correct; mock mode verifies API behavior, not model quality.
- **“The cost estimate may be wrong.”** It depends on current operator-supplied prices and provider usage values; it is not billing truth.
- **“Where are performance results?”** Run the included load test in a documented environment before reporting any numbers.
