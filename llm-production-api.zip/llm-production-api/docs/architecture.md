# Architecture

```mermaid
flowchart TD
  C[Client] --> A[FastAPI / auth / validation]
  A --> R[Rate limiter]
  R --> K{Cache hit?}
  K -- yes --> O[Validated response]
  K -- no --> P[Provider interface]
  P --> M[Deterministic mock]
  P --> X[Optional OpenAI-compatible provider]
  M --> U[Usage and estimated cost]
  X --> U
  U --> O
  O --> C
```

## Boundaries

- API layer: authentication, request validation, rate limiting, response contracts, request IDs.
- Provider interface: isolates vendor-specific transport from API behavior.
- Operational services: bounded TTL cache, in-memory rate limiter, process-local usage ledger.
- Mock provider: deterministic, keyless local mode for CI and demonstrations.

## Trade-offs

The cache and rate limiter are process-local; multi-worker or multi-replica deployments need a shared store. Streaming is an SSE transport demonstration that streams chunks after the provider returns a complete response; it is not true token-by-token upstream streaming. The API key auth is a learning baseline, not a substitute for an identity provider, user-level quotas, or key rotation.
